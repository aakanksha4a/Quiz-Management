<%@page import="java.util.Map"%>
<%@page import="java.util.HashMap"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.util.Random"%>
<%@page import="java.util.HashSet"%>
<%@page import="java.util.Set"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>

 
 <style type="text/css">
 body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(to right, #141e30, #243b55);
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    padding-top: 50px;
    color: #fff;
    overflow-y: auto;
}

.quiz-container {
    background: rgba(255, 255, 255, 0.08);
    border-radius: 16px;
    padding: 2.5rem 3rem;
    width: 700px;
    max-width: 90%;
    box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    text-align: left;
    box-sizing: border-box;
}

h2 {
    font-size: 1.5rem;
    color: #00ffc8;
    margin-bottom: 1rem;
}

label.option {
    display: block;
    background: rgba(255, 255, 255, 0.05);
    margin: 10px 0;
    padding: 10px 15px;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s ease;
}

label.option:hover {
    background: rgba(255, 255, 255, 0.15);
}

label.option input[type="radio"] {
    margin-right: 10px;
}

.btn {
    display: block;
    background-color: #00ffc8;
    color: #000;
    border: none;
    border-radius: 8px;
    font-size: 1rem;
    font-weight: bold;
    padding: 10px 20px;
    margin-top: 20px;
    cursor: pointer;
    transition: background 0.3s ease;
}

.btn:hover {
    background-color: #00c6a2;
}
 </style>

</head>
<body>
<div class="quiz-container">
<form action="pythonque.jsp" method="post">
<% 
String url="jdbc:mysql://localhost:3306/school_student";
String user="root";
String password="aakanksha01";


try{
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con = DriverManager.getConnection(url,user,password);
	
	if(session.getAttribute("randomid")==null){
	Set<Integer> randomid = new HashSet<>();
	Random rand = new Random();
	
	while(randomid.size()<5){
		int random = rand.nextInt(10)+1;
		randomid.add(random);
	}
	
	  Map<Integer, Integer> answerMap = new HashMap<>();
      session.setAttribute("answerMap", answerMap);
		
		session.setAttribute("randomid", randomid);
		session.setAttribute("count", 0);
		
	}
		Set<Integer>randomid = (Set<Integer>)session.getAttribute("randomid");
		int count = (int) session.getAttribute("count");
		
		
        Map<Integer, Integer> answerMap = (Map<Integer, Integer>) session.getAttribute("answerMap");

        
        if (count > 0) {
            for (int id : randomid) {
                String answerParam = "q" + id;  // Use ID-based parameter names
                String selectedOption = request.getParameter(answerParam);
                
                if (selectedOption != null && !selectedOption.isEmpty()) {
                    answerMap.put(id, Integer.parseInt(selectedOption));
                }
            }
        }
	
	if(count<5){
		int queid = (int)randomid.toArray()[count];
		
		
		String query = "SELECT * FROM python WHERE id = ?";
		PreparedStatement pst = con.prepareStatement(query);
		pst.setInt(1, queid);
		
		ResultSet rs = pst.executeQuery();
		
		while (rs.next()) {
           
			%>
			
			
			<h2>Q<%= count + 1 %>: <%= rs.getString("question") %></h2>
        <label class="option">
            <input type="radio" name="q<%= queid %>" value="1" <% if (answerMap.containsKey(queid) && answerMap.get(queid) == 1) { %> checked <% } %> >
            <%= rs.getString("option1") %>
        </label>
        <label class="option">
            <input type="radio" name="q<%= queid %>" value="2" <% if (answerMap.containsKey(queid) && answerMap.get(queid) == 2) { %> checked <% } %> >
            <%= rs.getString("option2") %>
        </label>
        <label class="option">
            <input type="radio" name="q<%= queid %>" value="3" <% if (answerMap.containsKey(queid) && answerMap.get(queid) == 3) { %> checked <% } %> >
            <%= rs.getString("option3") %>
        </label>
        <label class="option">
            <input type="radio" name="q<%= queid %>" value="4" <% if (answerMap.containsKey(queid) && answerMap.get(queid) == 4) { %> checked <% } %> >
            <%= rs.getString("option4") %>
        </label>

            
            
            <%
           
            session.setAttribute("count", count +1);
		}
		
		if(count<4){
			
  %> 
            <button type="submit" class="btn">Next</button>
            
  <%          }else{
            	
            	%>
            	 <button type="submit" class="btn" formaction="submitanswer.jsp">Submit</button>
<%
            }
		
		}
	}catch(Exception e ){
		
	 e.printStackTrace();
	}
%>		
		
  </form>
</div>

</body>
</html>
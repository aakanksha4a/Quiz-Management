<%@page import="java.util.Map"%>
<%@page import="java.util.Set"%>
<%@page import="java.sql.*"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Quiz Result</title>
    <style type="text/css">
    body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    padding-top: 50px;
    color: #fff;
    overflow-y: auto;
}

.container {
    background: rgba(255, 255, 255, 0.08);
    border-radius: 16px;
    padding: 2rem 2.5rem;
    width: 700px;
    max-width: 90%;
    box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    text-align: left;
    box-sizing: border-box;
}

h2.login-title {
    color: #00ffc8;
    margin-bottom: 1.5rem;
    font-size: 1.8rem;
    text-align: center;
}

h3 {
    color: #fffd8c;
    font-size: 1.2rem;
    margin-top: 1.5rem;
}

p {
    font-size: 1rem;
    margin: 0.5rem 0;
}

hr {
    border: 0;
    height: 1px;
    background: rgba(255, 255, 255, 0.2);
    margin: 1.5rem 0;
}

.score-text {
    font-size: 1.4rem;
    font-weight: bold;
    margin-top: 2rem;
    color: #00ffc8;
    text-align: center;
}

.score-text span {
    font-size: 1.5rem;
    color: #ffffff;
}

button {
    padding: 10px 20px;
    background-color: #00ffc8;
    color: #000;
    border: none;
    border-radius: 8px;
    font-weight: bold;
    font-size: 1rem;
    cursor: pointer;
    margin: 30px auto 0;
    display: block;
    transition: background 0.3s ease;
}

button:hover {
    background-color: #00c6a2;
}
    
    </style>
</head>
<body>
<div class="container">
    <h2 class="login-title">Quiz Result</h2>

    <%
        String url = "jdbc:mysql://localhost:3306/school_student";
        String user = "root";
        String password = "aakanksha01";
    
        int score = 0;
        int totalque = 0;
    
        String name = (String) session.getAttribute("name");
        String language = (String) session.getAttribute("language");
        Set<Integer> randomid = (Set<Integer>) session.getAttribute("randomid");
        Map<Integer, Integer> answerMap = (Map<Integer, Integer>) session.getAttribute("answerMap");
    
        if (randomid == null || answerMap == null || language == null) {
    %>
            <p>Error: Missing quiz data. Please restart the quiz.</p>
    <%
        } else {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection(url, user, password);
    
                String tableName = "";
                switch (language.toLowerCase()) {
                    case "java": tableName = "java"; break;
                    case "cpp": tableName = "cpp"; break;
                    case "c": tableName = "c"; break;
                    case "python": tableName = "python"; break;
                    default: tableName = "java";
                }
    
                String query = "SELECT question, option1, option2, option3, option4, correct_option FROM " + tableName + " WHERE id = ?";
                PreparedStatement pst = con.prepareStatement(query);
    
                for (int queid : randomid) {
                    pst.setInt(1, queid);
                    ResultSet rs = pst.executeQuery();
    
                    if (rs.next()) {
                        String question = rs.getString("question");
                        String option1 = rs.getString("option1");
                        String option2 = rs.getString("option2");
                        String option3 = rs.getString("option3");
                        String option4 = rs.getString("option4");
                        int correctAnswer = rs.getInt("correct_option");
    
                        int userAnswer = answerMap.getOrDefault(queid, 0);
                        if (userAnswer == correctAnswer) {
                            score++;
                        }
                        totalque++;
    %>
    
        

    
                        <h3>Q: <%= question %></h3>
                        <p>Your Answer: 
                            <strong><%= userAnswer == 1 ? option1 : userAnswer == 2 ? option2 : userAnswer == 3 ? option3 : option4 %></strong>
                        </p>
                        <p>Correct Answer: 
                            <strong><%= correctAnswer == 1 ? option1 : correctAnswer == 2 ? option2 : correctAnswer == 3 ? option3 : option4 %></strong>
                        </p>
                        <hr>
    <%
                    }
                }
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
    %>
                <p>Error retrieving quiz data. Please try again later.</p>
    <%
            }
        }
    %>
<p class="score-text">Your Score: <span><%= score %> / <%= totalque %></span></p>


    
<form action="loginpage.jsp">
<button type="submit" name="btn">Logout</button>
    </form>
</div>
</body>
</html>

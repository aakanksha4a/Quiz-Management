<%@page import="java.util.Map"%>
<%@page import="java.util.HashMap"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.util.Random"%>
<%@page import="java.util.HashSet"%>
<%@page import="java.util.Set"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.Connection"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>


<style type="text/css">
/* Tech-inspired glass background */
body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
}

/* Main container */
.quiz-container {
    background: rgba(255, 255, 255, 0.08);
    border-radius: 16px;
    padding: 2rem 2.5rem;
    width: 600px;
    max-width: 90%;
    box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    text-align: left;
}

/* Question styling */
h2 {
    margin-bottom: 1rem;
    color: #00ffc8;
}

/* Options layout */
.option {
    display: block;
    margin-bottom: 1rem;
    font-size: 1rem;
}

/* Buttons */
.btn {
    padding: 10px 20px;
    background-color: #00ffc8;
    color: #000;
    border: none;
    border-radius: 8px;
    font-weight: bold;
    font-size: 1rem;
    cursor: pointer;
    margin-top: 1rem;
    transition: background 0.3s ease;
}

.btn:hover {
    background-color: #00c6a2;
}
</style>
</head>
<body>
<div class="quiz-container">
<form action="cpage.jsp" method="post">
<% 
String url="jdbc:mysql://localhost:3306/school_student";
String user="root";
String password="aakanksha01";


try{
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con = DriverManager.getConnection(url,user,password);
	
	if(session.getAttribute("randomid")==null){
	Set<Integer> randomid = new HashSet<>();
	Random rand = new Random();
	
	while(randomid.size()<5){
		int random = rand.nextInt(10)+1;
		randomid.add(random);
	}
	
	  Map<Integer, Integer> answerMap = new HashMap<>();
      session.setAttribute("answerMap", answerMap);
		
		session.setAttribute("randomid", randomid);
		session.setAttribute("count", 0);
		
	}
		Set<Integer>randomid = (Set<Integer>)session.getAttribute("randomid");
		int count = (int) session.getAttribute("count");
		
		
        Map<Integer, Integer> answerMap = (Map<Integer, Integer>) session.getAttribute("answerMap");

        
        if (count > 0) {
            for (int id : randomid) {
                String answerParam = "q" + id;  // Use ID-based parameter names
                String selectedOption = request.getParameter(answerParam);
                
                if (selectedOption != null && !selectedOption.isEmpty()) {
                    answerMap.put(id, Integer.parseInt(selectedOption));
                }
            }
        }
	
	if(count<5){
		int queid = (int)randomid.toArray()[count];
		
		
		String query = "SELECT * FROM c WHERE id = ?";
		PreparedStatement pst = con.prepareStatement(query);
		pst.setInt(1, queid);
		
		ResultSet rs = pst.executeQuery();
		
		while (rs.next()) {
           
			%>
			
			
			
			<h2>Q<%= count + 1 %>: <%= rs.getString("question") %></h2>
        <label class="option">
            <input type="radio" name="q<%= queid %>" value="1" <% if (answerMap.containsKey(queid) && answerMap.get(queid) == 1) { %> checked <% } %> >
            <%= rs.getString("option1") %>
        </label>
        <label class="option">
            <input type="radio" name="q<%= queid %>" value="2" <% if (answerMap.containsKey(queid) && answerMap.get(queid) == 2) { %> checked <% } %> >
            <%= rs.getString("option2") %>
        </label>
        <label class="option">
            <input type="radio" name="q<%= queid %>" value="3" <% if (answerMap.containsKey(queid) && answerMap.get(queid) == 3) { %> checked <% } %> >
            <%= rs.getString("option3") %>
        </label>
        <label class="option">
            <input type="radio" name="q<%= queid %>" value="4" <% if (answerMap.containsKey(queid) && answerMap.get(queid) == 4) { %> checked <% } %> >
            <%= rs.getString("option4") %>
        </label>

            
            
            <%
           
            session.setAttribute("count", count +1);
		}
		
		if(count<4){
			
  %> 
            <button type="submit" class="btn">Next</button>
            
  <%          }else{
            	
            	%>
            	 <button type="submit" class="btn" formaction="submitanswer.jsp">Submit</button>
<%
            }
		
		}
	}catch(Exception e ){
		
	 e.printStackTrace();
	}
%>		
		
  </form>
</div>

</body>
</html>


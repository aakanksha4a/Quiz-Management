<%@page import="java.sql.*"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Reset Password</title>
<style type="text/css">
/* Full-page background with a tech theme */
body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(to right, #0f2027, #203a43, #2c5364); 
    background-size: cover;
    height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #fff;
}

/* Glass card design */
.container {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 16px;
    padding: 2rem;
    box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    border: 1px solid rgba(255, 255, 255, 0.18);
    width: 320px;
    text-align: center;
}

/* Title */
.login-title {
    font-size: 2rem;
    margin-bottom: 1.5rem;
    color: #00ffc8;
}

/* Input styling */
input[type="password"] {
    width: 90%;
    padding: 10px;
    margin: 8px 0;
    border: none;
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.2);
    color: white;
    outline: none;
}

input::placeholder {
    color: #ddd;
}

/* Button container */
.btn-container {
    margin-top: 1rem;
}

/* Buttons */
button {
    margin: 0.4rem;
    padding: 10px 20px;
    background-color: #00ffc8;
    color: #000;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: bold;
    transition: background 0.3s ease;
}

button:hover {
    background-color: #00c6a2;
}

/* Error messages */
.error {
    color: #ff4d4d;
    font-weight: bold;
    margin-top: 1rem;
}

</style>
</head>
<body>

<div class="container">
    <h1 class="login-title">Reset Your Password</h1>

    <form method="post" action="reset.jsp">
        <label><input type="password" name="newpwd" required placeholder="Enter New Password: "></label><br><br>
        <label><input type="password" name="newpwd1" required placeholder="Confirm Password: "></label><br><br>
        <button type="submit" name="action" value="reset">Reset Password</button>
    </form>

    <%
        String newPass = request.getParameter("newpwd");
        String confirmPass = request.getParameter("newpwd1");
        String action = request.getParameter("action");
        String unname = (String) session.getAttribute("unname");

        if ("reset".equals(action) && newPass != null && newPass.equals(confirmPass)) {
            String url = "jdbc:mysql://localhost:3306/school_student";
            String user = "root";
            String password = "aakanksha01";

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection cn = DriverManager.getConnection(url, user, password);

                String query = "UPDATE results SET upass = ? WHERE unname = ?";
                PreparedStatement pst = cn.prepareStatement(query);

                pst.setString(1, newPass);
                pst.setString(2, unname);

                int rows = pst.executeUpdate();
                if (rows > 0) {
                    out.print("<p>Password Changed Successfully!</p>");
                    response.sendRedirect("loginpage.jsp");
                } else {
                    out.print("<p class='error'>Password Update Failed!</p>");
                }
            } catch (Exception e) {
                out.print("<p class='error'>Error: " + e.getMessage() + "</p>");
            }
        }
    %>
</div>

</body>
</html>

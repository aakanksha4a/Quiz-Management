<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>


<p><strong>Your Score:</strong> <%= request.getParameter("score") %> / <%=request.getParameter("totalque")  %></p>
<form action="loginpage.jsp">
<button type="submit" name="btn">Logout</button>

</form>


</body>
</html>
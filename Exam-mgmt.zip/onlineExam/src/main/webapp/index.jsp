<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Start Quiz</title>
<style type="text/css">
/* Full-page tech background */
body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(to right, #0f2027, #203a43, #2c5364); 
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
}

/* Container for centering */
.container {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 16px;
    padding: 2.5rem;
    width: 350px;
    text-align: center;
    box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    border: 1px solid rgba(255, 255, 255, 0.18);
}

/* Title styling */
h1 {
    color: #00ffc8;
    margin-bottom: 2rem;
}

/* Input fields */
input[type="text"], select {
    width: 90%;
    padding: 10px;
    margin: 10px 0;
    background: rgba(255, 255, 255, 0.2);
    border: none;
    border-radius: 8px;
    color: white;
    font-size: 1rem;
    outline: none;
}

select option {
    background-color: #2c5364;
    color: white;
}

/* Submit button */
input[type="submit"] {
    padding: 10px 20px;
    margin-top: 1rem;
    border: none;
    border-radius: 8px;
    background-color: #00ffc8;
    color: black;
    font-weight: bold;
    cursor: pointer;
    transition: background 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #00c6a2;
}
</style>
</head>
<body>

<div class="container">
    <form method="post" action="firstpaage.jsp">
        <h1>✨ Start the Quiz ✨</h1>
        <input type="text" name="name" placeholder="Enter Your Name" required><br><br>
        <select name="language">
            <option>Select Language</option>
            <option value="c">C</option>
            <option value="cpp">C++</option>
            <option value="java">JAVA</option>
            <option value="python">PYTHON</option>
        </select><br><br>
        <input type="submit" value="Start">
    </form>
</div>

</body>
</html>

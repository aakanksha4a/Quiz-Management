<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<%@page import="java.sql.Connection"%>
<%@page import="java.sql.DriverManager"%>
<%@page import="java.sql.ResultSet"%>
<%@page import="java.sql.PreparedStatement"%>
<%@page import="java.sql.SQLIntegrityConstraintViolationException"%>
<html>
<head>
    <meta charset="UTF-8">
    
    <title>Field Page</title>
  <style type="text/css">
  /* Full-page background with a tech theme */
body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(to right, #0f2027, #203a43, #2c5364); 
    background-size: cover;
    height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #fff;
}

/* Header styling */
.header-container {
    position: absolute;
    top: 0;
    width: 100%;
    background: rgba(0, 0, 0, 0.5);
    padding: 1rem;
    text-align: center;
    font-size: 1.4rem;
    color: #00ffc8;
    letter-spacing: 1px;
}

/* Glass card design */
.glass-card {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 16px;
    padding: 2rem;
    box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    border: 1px solid rgba(255, 255, 255, 0.18);
    width: 320px;
    text-align: center;
}

.login-title {
    font-size: 1.8rem;
    margin-bottom: 1.5rem;
    color: #00ffc8;
}

/* Input styling */
input[type="text"],
input[type="password"] {
    width: 90%;
    padding: 10px;
    margin: 8px 0;
    border: none;
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.2);
    color: white;
    outline: none;
}

input::placeholder {
    color: #ddd;
}

/* Button container */
.btn-container {
    margin-top: 1rem;
}

/* Buttons */
.btn {
    margin: 0.4rem;
    padding: 10px 20px;
    background-color: #00ffc8;
    color: #000;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: bold;
    transition: background 0.3s ease;
}

.btn:hover {
    background-color: #00c6a2;
}

/* Admin button */
.admin-container {
    position: absolute;
    right: 20px;
    top: 20px;
}

.admin-btn {
    padding: 8px 16px;
    background-color: #ff4081;
    border: none;
    color: #fff;
    border-radius: 8px;
    cursor: pointer;
}

.admin-btn:hover {
    background-color: #e91e63;
}

/* Forget password link */
.fbtn {
    display: inline-block;
    margin-top: 1rem;
    color: #00ffc8;
    text-decoration: none;
    font-weight: bold;
}

.fbtn:hover {
    text-decoration: underline;
}

/* Error messages */
.error {
    color: #ff4d4d;
    font-weight: bold;
    margin-top: 1rem;
}
  </style>  
  
</head>
<body>
    <div class="header-container">
        <header>Winning is temporary, learning is forever!</header>
        <form method="post" action="AdminLoginpage.jsp">
            <div class="admin-container">
                <button type="submit" name="users" value="admin" class="admin-btn">Admin</button>
            </div>
        </form>
    </div>

    <div class="container">
        <div class="glass-card">
            <h1 class="login-title">Welcome to Login Form</h1>
            <form method="post">
                <label>
                    <input type="text" name="unname" placeholder="unique-username">
                </label>
                <label>
                    <input type="password" name="upass" placeholder="password">
                </label>
                <div class="btn-container">
                    <button type="submit" name="action" value="register" class="btn">Register</button>
                    <button type="submit" name="action" value="login" class="btn">Login</button>
                   
                   

                </div>
                 
            </form>
             <a href="forget.jsp" class="fbtn">Forget Password!</a>
        </div>
       
    </div>

<%
String unname = request.getParameter("unname");
String pass = request.getParameter("upass");
String action = request.getParameter("action");

if ("forget".equals(action)) {
    response.sendRedirect("forget.jsp");
    return;
}

if (request.getMethod().equalsIgnoreCase("post")) {
    if (unname == null || unname.isEmpty() || pass == null || pass.isEmpty()) {
        out.print("<p class='error'>Please fill in all fields.</p>");
    } else {
        String url = "jdbc:mysql://localhost:3306/school_student";
        String user = "root";
        String password = "aakanksha01";
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection cn = DriverManager.getConnection(url, user, password);
            
            if ("register".equals(action)) {
                String query = "SELECT * FROM results WHERE unname = ?";
                PreparedStatement stmt = cn.prepareStatement(query);
                stmt.setString(1, unname);
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    out.print("<p class='error'>User already exists! Please login.</p>");
                } else {
                    String insertQuery = "INSERT INTO results (unname, upass) VALUES (?, ?)";
                    PreparedStatement pst = cn.prepareStatement(insertQuery);
                    pst.setString(1, unname);
                    pst.setString(2, pass);
                    
                    int rows = pst.executeUpdate();
                    if (rows > 0) {
                        session.setAttribute("unname", unname);
                        response.sendRedirect("index.jsp");
                    } else {
                        out.print("<p class='error'>Registration Failed</p>");
                    }
                }
            } else if ("login".equals(action)) {
                String query = "SELECT * FROM results WHERE unname=?";
                PreparedStatement stmt = cn.prepareStatement(query);
                stmt.setString(1, unname);
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    String storedPassword = rs.getString("upass");
                    if (storedPassword.equals(pass)) {
                        session.setAttribute("unname", unname);
                        response.sendRedirect("index.jsp");
                    } else {
                        out.print("<p class='error'>Incorrect password! Try again.</p>");
                    }
                } else {
                    out.print("<p class='error'>No account found with this username! Please register.</p>");
                }
            }
        } catch (SQLIntegrityConstraintViolationException e) {
            out.print("<p class='error'>Username already taken! Try another.</p>");
        } catch (Exception e) {
            out.print("<p class='error'>Error: " + e.getMessage() + "</p>");
        }
    }
}
%>
</body>
</html>


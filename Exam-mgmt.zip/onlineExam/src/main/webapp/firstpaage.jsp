<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<style type="text/css">
/* Techy glassmorphism background */
body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
}

/* Main content box */
.container {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 16px;
    padding: 2rem 2.5rem;
    width: 500px;
    max-width: 90%;
    text-align: center;
    box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    border: 1px solid rgba(255, 255, 255, 0.18);
}

/* Welcome message */
.login-title {
    color: #00ffc8;
    font-size: 1.8rem;
    margin-bottom: 1rem;
}

/* Instructions block */
.instructions {
    font-size: 1rem;
    line-height: 1.7;
    text-align: left;
    padding: 1rem;
    background: rgba(255, 255, 255, 0.08);
    border-radius: 12px;
    margin-bottom: 1.5rem;
    border-left: 4px solid #00ffc8;
}

/* Start button */
button[type="submit"] {
    padding: 10px 20px;
    background-color: #00ffc8;
    border: none;
    border-radius: 8px;
    color: black;
    font-weight: bold;
    cursor: pointer;
    font-size: 1rem;
    transition: background 0.3s ease;
}

button[type="submit"]:hover {
    background-color: #00c6a2;
}
</style>
</head>
<body>
<div class="container">
    <h1 class="login-title">Welcome! <%= request.getParameter("name") %></h1>
    <div class="instructions">
        Instructions:
        <br>
        Total number of questions: 5.
        <br>
        Time allotted: 2 minutes.
        <br>
        Each question carries 1 mark; there are no negative marks.
        <br>
        DO NOT refresh the page.
        <br>
        All the best!
    </div>
    <br><br>
    <%
    String name = request.getParameter("name");
    String language = request.getParameter("language");

    session.setAttribute("name", name);
    session.setAttribute("language", language);

    if(language != null) {
        if(language.equals("c")) 
            out.print("<form action='cpage.jsp' method='post'>");
        else if(language.equals("cpp"))
            out.print("<form action='cpppage.jsp' method='post'>");
        else if(language.equals("java"))
            out.print("<form action='javaque.jsp' method='post'>");
        else if(language.equals("python"))
            out.print("<form action='pythonque.jsp' method='post'>");
        else
            out.print("Invalid Course Selection");
        
        out.print("<button type='submit'>Start Test</button></form>");
    } else {
        out.print("Error: No language selected. Please go back and select a language.");
    }
    %>
</div>
</body>
</html>
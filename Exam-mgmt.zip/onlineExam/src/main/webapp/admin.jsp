<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>
<style>

/* Full-page background with a tech theme */
body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(to right, #0f2027, #203a43, #2c5364); 
    background-size: cover;
    height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #fff;
}

/* Glass card design */
.glass-card {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 16px;
    padding: 2rem;
    box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    border: 1px solid rgba(255, 255, 255, 0.18);
    width: 320px;
    text-align: center;
}

/* Login Title */
.login-title {
    font-size: 1.8rem;
    margin-bottom: 1.5rem;
    color: #00ffc8;
}

/* Button container */
.btn-container {
    margin-top: 2rem;
}

/* Buttons */
.btn {
    margin: 0.4rem;
    padding: 10px 20px;
    background-color: #00ffc8;
    color: #000;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: bold;
    transition: background 0.3s ease;
}

.btn:hover {
    background-color: #00c6a2;
}
</style>
</head>
<body>

<% String aname = (String) session.getAttribute("aname"); %>

<div class="glass-card">
    <h1 class="login-title">Welcome, <%=aname%>!</h1>

    <div class="btn-container">
        <form action="add_question.jsp" method="post">
            <button type="submit" class="btn">Click Here To Add New Questions</button>
        </form>
        
        <form action="remove_question.jsp" method="post">
            <button type="submit" class="btn">Click Here To Remove Questions</button>
        </form>
        
        <form action="update_question.jsp" method="post">
            <button type="submit" class="btn">Click Here To Update Questions</button>
        </form>
    </div>

</div>

</body>
</html>

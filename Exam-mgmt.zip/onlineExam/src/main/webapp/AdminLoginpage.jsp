<%@page import="java.sql.*"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Login</title>
<style type="text/css">
/* Full-page background with a tech theme */
body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(to right, #0f2027, #203a43, #2c5364); 
    background-size: cover;
    height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #fff;
}

/* Header styling */
.header-container {
    position: absolute;
    top: 0;
    width: 100%;
    background: rgba(0, 0, 0, 0.5);
    padding: 1rem;
    text-align: center;
    font-size: 1.4rem;
    color: #00ffc8;
    letter-spacing: 1px;
}

/* Glass card design */
.glass-card {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 16px;
    padding: 2rem;
    box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    border: 1px solid rgba(255, 255, 255, 0.18);
    width: 320px;
    text-align: center;
}

.login-title {
    font-size: 1.8rem;
    margin-bottom: 1.5rem;
    color: #00ffc8;
}

/* Input styling */
input[type="text"],
input[type="password"] {
    width: 90%;
    padding: 10px;
    margin: 8px 0;
    border: none;
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.2);
    color: white;
    outline: none;
}

input::placeholder {
    color: #ddd;
}

/* Button container */
.btn-container {
    margin-top: 1rem;
}

/* Buttons */
.btn {
    margin: 0.4rem;
    padding: 10px 20px;
    background-color: #00ffc8;
    color: #000;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: bold;
    transition: background 0.3s ease;
}

.btn:hover {
    background-color: #00c6a2;
}

/* Admin button */
.admin-container {
    position: absolute;
    right: 20px;
    top: 20px;
}

.admin-btn {
    padding: 8px 16px;
    background-color: #ff4081;
    border: none;
    color: #fff;
    border-radius: 8px;
    cursor: pointer;
}

.admin-btn:hover {
    background-color: #e91e63;
}

/* Forget password link */
.fbtn {
    display: inline-block;
    margin-top: 1rem;
    color: #00ffc8;
    text-decoration: none;
    font-weight: bold;
}

.fbtn:hover {
    text-decoration: underline;
}

/* Error messages */
.error {
    color: #ff4d4d;
    font-weight: bold;
    margin-top: 1rem;
}
</style>
</head>
<body>

<div class="glass-card">
    <h1 class="login-title">Admin Login</h1>

    <form method="post">
        <input type="text" name="aname" placeholder="Enter Your Name" required>
        <input type="password" name="pswd" placeholder="Enter Your Password" required>
        <button type="submit" name="btn" class="btn">PLEASE LOGIN</button> 
    </form>

    <%
    String aname = request.getParameter("aname");
    String pswd = request.getParameter("pswd");

    if (request.getMethod().equalsIgnoreCase("post") && 
        aname != null && !aname.isEmpty() && 
        pswd != null && !pswd.isEmpty()) {

        String url = "jdbc:mysql://localhost:3306/school_student";
        String user = "root";
        String password = "aakanksha01";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, password);

            String query = "SELECT * FROM admins WHERE name = ? AND pswd = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, aname);
            pst.setString(2, pswd);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {  
                session.setAttribute("aname", aname);
                response.sendRedirect("admin.jsp");
            } else {
                out.print("<p class='error-msg'>No such admin found! Please try again.</p>");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            out.print("<p class='error-msg'>Error: " + e.getMessage() + "</p>");
        } 
    }
    %>
</div>

</body>
</html>

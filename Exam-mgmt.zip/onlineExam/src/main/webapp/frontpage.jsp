<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Login Page</title>

</head>
<body>

<!-- Floating Abstract Blue Blurry Shapes -->
<div class="background-shape"></div>
<div class="background-shape"></div>

<div class="container">
    <h1>LOGIN</h1>
    <form method="post" action="">
        <label>Select User:</label>
        <select name="user">
            <option value="">~~Select~~</option>
            <option value="anm">Admin</option>
            <option value="std">Student</option>
        </select>
        
        <input type="submit" class="btn" value="Login">
    </form>
</div>

<% 
String user = request.getParameter("user");

if (user != null) { 
    if (user.equals("anm")) { 
        response.sendRedirect("admin.jsp");
    } else if (user.equals("std")) {
        response.sendRedirect("index.jsp");
    } else {
        out.print("<p>Invalid User Selection</p>");
    }
}
%>

</body>
</html>
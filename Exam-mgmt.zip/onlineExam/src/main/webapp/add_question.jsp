
<%@page import="java.sql.*"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Add Question</title>
   <style>
   /* Full-page background with a tech theme */
body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(to right, #0f2027, #203a43, #2c5364); 
    background-size: cover;
    height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #fff;
}

/* Container for the form */
.container {
    background: rgba(255, 255, 255, 0.15);
    border-radius: 16px;
    padding: 2rem;
    box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    border: 1px solid rgba(255, 255, 255, 0.18);
    width: 320px;
    text-align: center;
    margin-top: 50px; /* Ensure it's not at the very top */
}

/* Heading for the page */
h2 {
    font-size: 1.8rem;
    margin-bottom: 1.5rem;
    color: #00ffc8;
    text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5); /* Add shadow for better visibility */
}

/* Label styling */
label {
    font-size: 1.1rem;
    margin-bottom: 0.5rem;
    color: #fff;
    display: block;
}

/* Input and select field styling */
input[type="text"],
input[type="number"],
select {
    width: 90%;
    padding: 10px;
    margin: 8px 0;
    border: none;
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.3); /* Slightly more opaque for better visibility */
    color: #fff;
    outline: none;
}

input::placeholder {
    color: #ddd;
}

/* Group for options */
.option-group {
    margin-top: 1rem;
}

/* Buttons styling */
.btn-container {
    margin-top: 1rem;
}

.btn {
    margin: 0.4rem;
    padding: 10px 20px;
    background-color: #00ffc8;
    color: #000;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: bold;
    transition: background 0.3s ease;
}

.btn:hover {
    background-color: #00c6a2;
}

/* Success/Error messages styling */
p {
    font-size: 1rem;
    font-weight: bold;
}

p[style*="color: green"] {
    color: #00ff00;
}

p[style*="color: red"] {
    color: #ff4d4d;
}
   </style>
   
</head>
<body>
    <div class="container">
        <h2>Add a New Question</h2>

        <form method="post">
            <label>Select Subject:</label>
            <select name="subject" required>
                <option value="" selected disabled>~ Select Subject ~</option>
                <option value="c">C</option>
                <option value="cpp">C++</option>
                <option value="java">Java</option>
                <option value="python">Python</option>
            </select>

            <label>Question:</label>
            <input type="text" name="question" required>

            <div class="option-group">
                <input type="text" name="option1" placeholder="Option 1" required>
                <input type="text" name="option2" placeholder="Option 2" required>
            </div>
            <div class="option-group">
                <input type="text" name="option3" placeholder="Option 3" required>
                <input type="text" name="option4" placeholder="Option 4" required>
            </div>

            <label>Correct Answer (1-4):</label>
            <input type="number" name="correct_option" min="1" max="4" required>

            <button type="submit" class="btn">➕ Add Question</button>
        </form>

        <%
        if (request.getMethod().equalsIgnoreCase("post")) {
            String subject = request.getParameter("subject");
            String question = request.getParameter("question");
            String option1 = request.getParameter("option1");
            String option2 = request.getParameter("option2");
            String option3 = request.getParameter("option3");
            String option4 = request.getParameter("option4");
            String correctOptionStr = request.getParameter("correct_option");
            int correctOption = 0;

            if (correctOptionStr != null && !correctOptionStr.isEmpty()) {
                correctOption = Integer.parseInt(correctOptionStr);
            } else {
                out.println("<p style='color: red;'>Error: Correct answer field is empty!</p>");
                return;
            }

            String url = "jdbc:mysql://localhost:3306/school_student";
            String user = "root";
            String password = "aakanksha01";

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection(url, user, password);
                
                if (subject.matches("^[a-zA-Z0-9_]+$")) { 
                    String query = "INSERT INTO " + subject + " (question, option1, option2, option3, option4, correct_option) VALUES (?, ?, ?, ?, ?, ?)";
                    PreparedStatement pst = con.prepareStatement(query);
                    pst.setString(1, question);
                    pst.setString(2, option1);
                    pst.setString(3, option2);
                    pst.setString(4, option3);
                    pst.setString(5, option4);
                    pst.setInt(6, correctOption);

                    int row = pst.executeUpdate();
                    if (row > 0) {
                        out.println("<p style='color: green;'>✅ Question added successfully!</p>");
                    } else {
                        out.println("<p style='color: red;'>❌ Error adding question.</p>");
                    }

                    pst.close();
                    con.close();
                } else {
                    out.println("<p style='color: red;'>Invalid subject selection!</p>");
                }
            } catch (Exception e) {
                out.println("<p style='color: red;'>Error: " + e.getMessage() + "</p>");
                e.printStackTrace();
            }
        }
        %>

        <div class="btn-container">
            <a href="add_question.jsp"><button type="button" class="btn">➕ Add Another</button></a>
            <a href="admin.jsp"><button type="button" class="btn">🔙 Back</button></a>
        </div>
    </div>
</body>
</html>
<%@page import="java.sql.*"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forget Password</title>
    <style type="text/css">
        /* Full-page background with a tech theme */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #0f2027, #203a43, #2c5364); 
            background-size: cover;
            height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: #fff;
        }

        /* Container for the form */
        .container {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 16px;
            padding: 2rem;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.18);
            width: 80%;
            max-width: 600px;
            text-align: center;
            margin-top: 50px;
        }

        /* Heading for the page */
        h1 {
            font-size: 1.8rem;
            margin-bottom: 1.5rem;
            color: #00ffc8;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
        }

        /* Label styling */
        label {
            font-size: 1.1rem;
            margin-bottom: 0.5rem;
            color: #fff;
            display: block;
        }

        /* Input field styling */
        input[type="text"] {
            width: 90%;
            padding: 10px;
            margin: 8px 0;
            border: none;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.3);
            color: #fff;
            outline: none;
        }

        input::placeholder {
            color: #ddd;
        }

        /* Button styling */
        button {
            margin-top: 1rem;
            padding: 10px 20px;
            background-color: #00ffc8;
            color: #000;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.3s ease;
        }

        button:hover {
            background-color: #00c6a2;
        }

        /* Error message styling */
        .error {
            color: #ff4d4d;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Forget Password</h1>
        <form method="post" action="forget.jsp">
            <label class="login-title">Enter Username:</label>
            <input type="text" name="unname" placeholder="Username" required>
            <button type="submit" name="action" value="verify">Verify User</button>
        </form>

    <%
        String unname = request.getParameter("unname");
        String action = request.getParameter("action");

        if ("verify".equals(action) && unname != null && !unname.isEmpty()) {
            String url = "jdbc:mysql://localhost:3306/school_student";
            String user = "root";
            String password = "aakanksha01";

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection cn = DriverManager.getConnection(url, user, password);
                String query = "SELECT * FROM results WHERE unname = ?";
                PreparedStatement pst = cn.prepareStatement(query);
                pst.setString(1, unname);
                ResultSet rs = pst.executeQuery();

                if (rs.next()) {
                    session.setAttribute("unname", unname);
                    response.sendRedirect("reset.jsp");
                } else {
                    out.print("<p class='error'>User not found!</p>");
                }
            } catch (Exception e) {
                out.print("<p class='error'>Error: " + e.getMessage() + "</p>");
            }
        }
    %>
</div>

</body>
</html>

<%@page import="java.sql.*"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<%
    String url = "jdbc:mysql://localhost:3306/school_student";
    String user = "root";
    String password = "aakanksha01";

    String subject = request.getParameter("subject");
    String id = request.getParameter("id");

    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection(url, user, password);
        PreparedStatement pst = con.prepareStatement("DELETE FROM " + subject + " WHERE id = ?");
        pst.setInt(1, Integer.parseInt(id));

        int rows = pst.executeUpdate();
        con.close();

        if (rows > 0) {
            response.sendRedirect("admin.jsp?message=Question Deleted Successfully");
        } else {
            response.sendRedirect("admin.jsp?error=Failed to Delete Question");
        }
    } catch (Exception e) {
        e.printStackTrace();
        response.sendRedirect("index.jsp?error=Error: " + e.getMessage());
    }
%>
<a href="add_question.jsp">➕ Add New Question</a>
    <form action="admin.jsp">
    <button type="submit" name="btn">Back</button></form>
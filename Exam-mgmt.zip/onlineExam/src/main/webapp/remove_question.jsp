<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.sql.*" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Remove Question</title>
   <style type="text/css">
   /* Full-page background with a tech theme */
body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(to right, #0f2027, #203a43, #2c5364); 
    background-size: cover;
    height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #fff;
}

/* Container for the form */
.container {
    background: rgba(255, 255, 255, 0.15);
    border-radius: 16px;
    padding: 2rem;
    box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    border: 1px solid rgba(255, 255, 255, 0.18);
    width: 320px;
    text-align: center;
    margin-top: 50px; /* Ensure it's not at the very top */
}

/* Heading for the page */
h2 {
    font-size: 1.8rem;
    margin-bottom: 1.5rem;
    color: #00ffc8;
    text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5); /* Add shadow for better visibility */
}

/* Label styling */
label {
    font-size: 1.1rem;
    margin-bottom: 0.5rem;
    color: #fff;
    display: block;
}

/* Input and select field styling */
input[type="text"],
input[type="number"],
select {
    width: 90%;
    padding: 10px;
    margin: 8px 0;
    border: none;
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.3); /* Slightly more opaque for better visibility */
    color: #fff;
    outline: none;
}

input::placeholder {
    color: #ddd;
}

/* Group for options */
.option-group {
    margin-top: 1rem;
}

/* Buttons styling */
.btn-container {
    margin-top: 1rem;
}

.btn {
    margin: 0.4rem;
    padding: 10px 20px;
    background-color: #00ffc8;
    color: #000;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: bold;
    transition: background 0.3s ease;
}

.btn:hover {
    background-color: #00c6a2;
}

/* Success/Error messages styling */
p {
    font-size: 1rem;
    font-weight: bold;
}

p[style*="color: green"] {
    color: #00ff00;
}

p[style*="color: red"] {
    color: #ff4d4d;
}
   </style>
</head>
<body>
    <div class="container">
        <h2 class="login-title">Remove Question</h2>
        
        <form method="post" action="remove_question.jsp">
            <label>Select Subject:</label>
            <select name="subject">
                <option value="">~~ Select Subject ~~</option>
                <option value="c">C</option>
                <option value="cpp">C++</option>
                <option value="java">Java</option>
                <option value="python">Python</option>
            </select>

            <label>Enter Question ID:</label>
            <input type="number" name="question_id" required>

            <div class="btn-container">
                <button type="submit" class="btn">❌ Remove</button>
            </div>
        </form>

        <%
            String subject = request.getParameter("subject");
            String questionId = request.getParameter("question_id");

            if (subject != null && !subject.isEmpty() && questionId != null && !questionId.isEmpty()) {
                Connection con = null;
                PreparedStatement pst = null;
                String url = "jdbc:mysql://localhost:3306/school_student";
                String user = "root";
                String password = "aakanksha01";

                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    con = DriverManager.getConnection(url, user, password);

                    // ✅ Validate subject (to prevent SQL Injection)
                    if (!subject.equals("c") && !subject.equals("cpp") && !subject.equals("java") && !subject.equals("python")) {
                        out.println("<p style='color:red;'>❌ Invalid subject!</p>");
                    } else {
                        String query = "DELETE FROM " + subject + " WHERE id=?";
                        pst = con.prepareStatement(query);
                        pst.setInt(1, Integer.parseInt(questionId));

                        int rowsAffected = pst.executeUpdate();
                        if (rowsAffected > 0) {
                            out.println("<p style='color:lightgreen;'>✅ Question removed successfully!</p>");
                        } else {
                            out.println("<p style='color:red;'>⚠️ Question ID not found!</p>");
                        }
                    }
                } catch (Exception e) {
                    out.println("<p style='color:red;'>❌ Error: " + e.getMessage() + "</p>");
                    e.printStackTrace();
                } finally {
                    if (pst != null) pst.close();
                    if (con != null) con.close();
                } 
            }
        %>

        <div class="btn-container">
            <a href="add_question.jsp"><button type="button" class="btn">➕ Add New</button></a>
            <a href="admin.jsp"><button type="button" class="btn">🔙 Back</button></a>
        </div>
    </div>
</body>
</html>
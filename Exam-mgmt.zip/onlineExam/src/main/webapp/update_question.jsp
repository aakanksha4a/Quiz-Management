<%@page import="java.sql.*"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Questions</title>
    <style type="text/css">
        /* Full-page background with a tech theme */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #0f2027, #203a43, #2c5364); 
            background-size: cover;
            height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: #fff;
        }

        /* Container for the form */
        .container {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 16px;
            padding: 2rem;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.18);
            width: 80%;
            max-width: 1200px;
            text-align: center;
            margin-top: 50px;
        }

        /* Heading for the page */
        h2 {
            font-size: 1.8rem;
            margin-bottom: 1.5rem;
            color: #00ffc8;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5); /* Add shadow for better visibility */
        }

        /* Label styling */
        label {
            font-size: 1.1rem;
            margin-bottom: 0.5rem;
            color: #fff;
            display: block;
        }

        /* Input and select field styling */
        input[type="text"],
        input[type="number"],
        select {
            width: 90%;
            padding: 10px;
            margin: 8px 0;
            border: none;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.3); /* Slightly more opaque for better visibility */
            color: #fff;
            outline: none;
        }

        input::placeholder {
            color: #ddd;
        }

        /* Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #00ffc8;
            color: #000;
        }

        td {
            background-color: rgba(255, 255, 255, 0.1);
        }

        /* Buttons styling */
        .btn-container {
            margin-top: 1rem;
        }

        .btn {
            margin: 0.4rem;
            padding: 10px 20px;
            background-color: #00ffc8;
            color: #000;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.3s ease;
        }

        .btn:hover {
            background-color: #00c6a2;
        }

        /* Success/Error messages styling */
        p {
            font-size: 1rem;
            font-weight: bold;
        }

        p[style*="color: green"] {
            color: #00ff00;
        }

        p[style*="color: red"] {
            color: #ff4d4d;
        }

        .small-btn {
            font-size: 1rem;
            padding: 8px 16px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Manage Questions</h2>
        <form method="post">
            <label>Select Subject:</label><br><br>
            <select name="subject">
                <option value="">~Select Language~</option>
                <option value="c">C</option>
                <option value="cpp">C++</option>
                <option value="java">Java</option>
                <option value="python">Python</option>
            </select><br><br>
            <button type="submit" class="btn">Load Questions</button>
        </form>
        
        <% 
        String url = "jdbc:mysql://localhost:3306/school_student";
        String user = "root";
        String password = "aakanksha01";
        String subject = request.getParameter("subject");

        if (subject != null && !subject.isEmpty()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection(url, user, password);
                Statement stmt = con.createStatement();

                if (subject.matches("^[a-zA-Z0-9_]+$")) { 
                    String query = "SELECT * FROM " + subject;
                    ResultSet rs = stmt.executeQuery(query);
        %>
        
        <h2>Questions for <%= subject.toUpperCase() %></h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Question</th>
                <th>Option 1</th>
                <th>Option 2</th>
                <th>Option 3</th>
                <th>Option 4</th>
                <th>Correct Option</th>
                <th>Actions</th>
            </tr>
            <% while (rs.next()) { %>
            <tr>
                <td><%= rs.getInt("id") %></td>
                <td><%= rs.getString("question") %></td>
                <td><%= rs.getString("option1") %></td>
                <td><%= rs.getString("option2") %></td>
                <td><%= rs.getString("option3") %></td>
                <td><%= rs.getString("option4") %></td>
                <td><%= rs.getInt("correct_option") %></td>
                <td>
                    <a href="update_question.jsp?id=<%= rs.getInt("id") %>&subject=<%= subject %>">✏ Edit</a> |
                    <a href="delete_question.jsp?id=<%= rs.getInt("id") %>&subject=<%= subject %>" onclick="return confirm('Are you sure?');">🗑 Delete</a>
                </td>
            </tr>
            <% } %>
        </table>
        <% 
                    rs.close();
                    stmt.close();
                    con.close();
                } else {
                    out.println("<p style='color:red;'>Invalid table name!</p>");
                }
            } catch (Exception e) {
                out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
                e.printStackTrace();
            }
        }
        %>

        <div class="btn-container">
            <a href="add_question.jsp" class="btn small-btn">➕ Add New Question</a>
            <a href="admin.jsp" class="btn small-btn">🔙 Back</a>
        </div>
    </div>

</body>
</html>
